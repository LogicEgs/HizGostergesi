﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace hizGostergesi1Son
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void trHizAyari_Scroll(object sender, EventArgs e)
        {
            // Kaydırıcının sayısını aldık
            int hiz = trHizAyari.Value;

            // Barı ilerlet ve yazıyı güncelle
            pbHiz.Value = hiz;
            lblHizDegeri.Text = "Hız: " + hiz.ToString() + " km/h";

            // label yazısı değiştirdik
            if (hiz > 120)
            {
                // Eğer hız 120'den büyükse yazıyı kırmızı yap
                lblHizDegeri.ForeColor = Color.Red;
            }
            else
            {
                // Değilse normal (siyah) renkte kalsın
                lblHizDegeri.ForeColor = Color.Black;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Hız artırma çubuğunu en başa çekiyoruz 
            trHizAyari.Value = 0;
            // Görsel doluluk çubuğunu da sıfır yapıyoruz
            pbHiz.Value = 0;
            // Ekranda ilk başta "Hız: 0 km/h" yazdırıyoruz
            lblHizDegeri.Text = "Hız: 0 km/h";
        }
    }
}