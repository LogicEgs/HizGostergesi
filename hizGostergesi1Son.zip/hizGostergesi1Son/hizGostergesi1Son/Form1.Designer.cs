﻿namespace hizGostergesi1Son
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.trHizAyari = new System.Windows.Forms.TrackBar();
            this.pbHiz = new System.Windows.Forms.ProgressBar();
            this.lblHizDegeri = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trHizAyari)).BeginInit();
            this.SuspendLayout();
            // 
            // trHizAyari
            // 
            this.trHizAyari.Location = new System.Drawing.Point(230, 103);
            this.trHizAyari.Maximum = 200;
            this.trHizAyari.Name = "trHizAyari";
            this.trHizAyari.Size = new System.Drawing.Size(220, 45);
            this.trHizAyari.TabIndex = 1;
            this.trHizAyari.Scroll += new System.EventHandler(this.trHizAyari_Scroll);
            // 
            // pbHiz
            // 
            this.pbHiz.Location = new System.Drawing.Point(295, 210);
            this.pbHiz.Maximum = 200;
            this.pbHiz.Name = "pbHiz";
            this.pbHiz.Size = new System.Drawing.Size(100, 23);
            this.pbHiz.TabIndex = 2;
            // 
            // lblHizDegeri
            // 
            this.lblHizDegeri.AutoSize = true;
            this.lblHizDegeri.Location = new System.Drawing.Point(320, 56);
            this.lblHizDegeri.Name = "lblHizDegeri";
            this.lblHizDegeri.Size = new System.Drawing.Size(62, 13);
            this.lblHizDegeri.TabIndex = 3;
            this.lblHizDegeri.Text = "Hız: 0 km/h";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblHizDegeri);
            this.Controls.Add(this.pbHiz);
            this.Controls.Add(this.trHizAyari);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.trHizAyari)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trHizAyari;
        private System.Windows.Forms.ProgressBar pbHiz;
        private System.Windows.Forms.Label lblHizDegeri;
    }
}

