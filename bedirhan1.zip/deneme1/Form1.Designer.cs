﻿namespace deneme1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pbHiz = new ProgressBar();
            trHizAyari = new TrackBar();
            lblHizDegeri = new Label();
            ((System.ComponentModel.ISupportInitialize)trHizAyari).BeginInit();
            SuspendLayout();
            // 
            // pbHiz
            // 
            pbHiz.Location = new Point(290, 266);
            pbHiz.Name = "pbHiz";
            pbHiz.Size = new Size(145, 34);
            pbHiz.TabIndex = 0;
            // 
            // trHizAyari
            // 
            trHizAyari.Location = new Point(290, 175);
            trHizAyari.Name = "trHizAyari";
            trHizAyari.Size = new Size(145, 56);
            trHizAyari.TabIndex = 1;
            trHizAyari.Scroll += trackBar1_Scroll;
            // 
            // lblHizDegeri
            // 
            lblHizDegeri.AutoSize = true;
            lblHizDegeri.Location = new Point(325, 85);
            lblHizDegeri.Name = "lblHizDegeri";
            lblHizDegeri.Size = new Size(50, 20);
            lblHizDegeri.TabIndex = 2;
            lblHizDegeri.Text = "label1";
            lblHizDegeri.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblHizDegeri);
            Controls.Add(trHizAyari);
            Controls.Add(pbHiz);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)trHizAyari).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ProgressBar pbHiz;
        private TrackBar trHizAyari;
        private Label lblHizDegeri;
    }
}
