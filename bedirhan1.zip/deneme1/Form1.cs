using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace deneme1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
            private void trackBar1_Scroll(object sender, EventArgs e)
        {
            // Kaydırıcının sayısını aldık
            int hiz = trHizAyari.Value;

            // Barı ilerlet ve yazıyı güncelle
            pbHiz.Value = hiz;
            lblHizDegeri.Text = "Hız: " + hiz.ToString() + " km/h";
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
      
        {
            // 1. Adım: Hız artırma çubuğunu en başa çekiyoruz
            trHizAyari.Value = 0;

            // 2. Adım: Görsel doluluk çubuğunu da sıfır yapıyoruz
            pbHiz.Value = 0;

            // 3. Adım: Ekranda ilk başta "Hız: 0 km/h" yazdırıyoruz
            lblHizDegeri.Text = "Hız: 0 km/h";
        }
    }
    }
}
